package Testing;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class date {

	public static String tenderDate;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	WebDriver driver=new ChromeDriver();
		
		Calendar calendar = Calendar.getInstance();
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		System.out.println(formatter.format(calendar.getTime()));
		System.out.println(calendar.getTime());
		
	/*	int [] date = {1,2,3,4};
		//int noOfIteration = 0;
		for(int d=1;d<=MahaTendersWebsiteAutomation.noOfIteration;d++)
		{

			tenderDate = driver.findElement(By.xpath("//*[@id='informal_'"+date[d]+"']/td[2]")).getText();
		System.out.println(tenderDate);

					driver.findElement(By.xpath("//*[@id='informal_'"+date[d]+"']/td[2]")).click();
					
					String str = "11-Oct-2019 09:00 AM"; 
			        String[] arrOfStr = str.split(" "); 
			  
			        for (String a : arrOfStr) 
			            System.out.println(a);
			        System.out.println(arrOfStr[0]);
			    } */
					
			      //*[@id="table"]
			        
		}
		
	}

//}





