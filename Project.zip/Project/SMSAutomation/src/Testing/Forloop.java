package Testing;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.By;

import com.mongodb.util.JSON;

public class Forloop 
{
	public static String fetchTxtOthers;
	public static String tenderDateOthers;
	public static String tenderDateFirst;
	public static String tenderDateFirstOthers;
	public static String fetchzonefirst1;
	public static String fetchzoneothers1;
	//public static int[] list;
	//public static int noOfIteration;
	public static SimpleDateFormat formatterOthers;
	public static String[] fetchzonefirst;
	public static String[] fetchzoneothers;
	public static String fetchzonefirst2;
	//public static String fetchzoneothers2;


public  void executeForLoop() throws Exception
{
	Thread.sleep(7000);
	Calendar calendar = Calendar.getInstance();
	JsonFIle data = new JsonFIle();
	calendar.add(Calendar.DATE, 0);
	//System.out.println(calendar.add(Calendar.DATE, 0));
	
	System.out.println(MahaTendersWebsiteAutomation.elePath[MahaTendersWebsiteAutomation.a]);
	MahaTendersWebsiteAutomation.foundele = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='DirectLink_"+MahaTendersWebsiteAutomation.elePath[MahaTendersWebsiteAutomation.a-2]+"']")).getText();
	System.out.println("fetchTxtOthers:"+MahaTendersWebsiteAutomation.foundele);
	
	
	int noOfIteration = Integer.parseInt(MahaTendersWebsiteAutomation.foundele);
	System.out.println("noOfIteration:"+noOfIteration);
	
	MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='DirectLink_"+MahaTendersWebsiteAutomation.elePath[MahaTendersWebsiteAutomation.a-2]+"']")).click();
	
	//2nd element 1st row
	
	int[] list = new int[]{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,
			39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,
			80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121};

	 //system date (i.e todays date)
		 formatterOthers = new SimpleDateFormat("dd-MMM-yyyy");
		 System.out.println(formatterOthers.format(calendar.getTime()));
		//fetch tender date for 1st row
		 tenderDateFirst = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='informal_1']/td[2]")).getText(); //*[@id="informal_2"]/td[2]
		 System.out.println("tenderDateFirst:"+tenderDateFirst);
		 
		 String[] arrOfDateFirst1 = tenderDateFirst.split(" "); 
		   System.out.println("arrOfDateFirst1:"+arrOfDateFirst1[0]);
		   
			if((formatterOthers.format(calendar.getTime())).equals(arrOfDateFirst1[0]))
		 	{
			   Thread.sleep(7000);
			   fetchzonefirst1 =  MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='informal_1']/td[6]")).getText();  //*[@id="informal_2"]/td[6]
			   fetchzonefirst = fetchzonefirst1.split("\\|\\|");
			   System.out.println("First zone"+fetchzonefirst);
			   fetchzonefirst2=fetchzonefirst[1];
				  
			   //click 1st element
			   
					 MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='DirectLink']")).click();
					 data.FetchRequireddataWithzone(MahaTendersWebsiteAutomation.elementPath);
					 Thread.sleep(7000);
			}
			else
			{
				System.out.println("No element found");
			}
				
		//2nd element from 2nd row
		for (int k = 0; k < noOfIteration-1; k++)
		{
			//system date (i.e todays date)
			 SimpleDateFormat formatter3 = new SimpleDateFormat("dd-MMM-yyyy");
			 System.out.println(formatter3.format(calendar.getTime()));
			 
			//fetch tender date from 2nd row
			 tenderDateOthers = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='informal_"+list[k+2]+"']/td[2]")).getText();      //*[@id="informal_2"]/td[2]
			 System.out.println("tenderDateOthers:"+tenderDateOthers); 
			 
			 String[] arrOfDateOthers = tenderDateOthers.split(" "); 
			 System.out.println("arrOfDateOthers:"+arrOfDateOthers[0]); 
			
	    //    System.out.println("expected date :"+datexp);
			if((formatter3.format(calendar.getTime())).equals(arrOfDateOthers[0]))
	        {
				Thread.sleep(7000);
				 fetchzoneothers1 =  MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='informal_"+list[k+2]+"']/td[6]")).getText();
				 fetchzoneothers = fetchzoneothers1.split("\\|\\|");
				 System.out.println("Others zone"+fetchzoneothers);
				 fetchzonefirst2=fetchzoneothers[1];
				 
				 MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='DirectLink_"+list[k]+"']")).click();
				 data.FetchRequireddataWithzone(MahaTendersWebsiteAutomation.elementPath);
	        }
		 else
		 {
			 break;
		 }
		}
		Thread.sleep(7000);
		
		MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='PageLink_15']")).click();
 }

}