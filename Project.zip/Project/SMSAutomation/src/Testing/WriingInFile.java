package Testing;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class WriingInFile 
{
	
	
	public static void main(String[] args) throws Exception
	{
	
	Calendar calendar = Calendar.getInstance();
	SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
	
	FileWriter fr=new FileWriter("C:\\New folder\\"+formatter.format(calendar.getTime())+".txt");
	BufferedWriter br=new BufferedWriter(fr);
	br.write("data");
	br.write("\nform");
	br.newLine();

	br.close();

	}

	}
