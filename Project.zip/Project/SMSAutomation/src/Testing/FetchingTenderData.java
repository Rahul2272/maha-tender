package Testing;

import java.io.BufferedWriter;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WriteException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FetchingTenderData 
{
	//String currentURL = null;

	public void FetchRequireddataWithzoneold(String filename) throws IOException, Exception
	{
				//currentURL = MahaTendersWebsiteAutomation.driver.getCurrentUrl();
		        //System.out.println(currentURL);
		        
				//Organization Chain
			//     fetchOrganizationChain = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[1]/td[2]")).getText();
			//	System.out.println("Org chain :"+fetchOrganizationChain);
		
				//fetch Tender ID
				String fetchTenderID = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[3]/td[2]")).getText();
				System.out.println("Tender ID :"+fetchTenderID);
		
				//Fetch Form of contract
				String	formOfContract = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[4]/td[4]")).getText();
				System.out.println("Form of contract : "+formOfContract);
				
				//fetch title 
				String fetchTenderTitle = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[14]/td/table/tbody/tr[1]/td[2]")).getText();
				System.out.println("Tender Title :"+fetchTenderTitle);
				
				//Fetch Tender value
				String fetchTenderValue = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[14]/td/table/tbody/tr[5]/td[2]")).getText();
				System.out.println("Tender Value : "+fetchTenderValue);
				
				//Fetch Tender Fee
				String fetchTenderFee = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[9]/td/table/tbody/tr/td[1]/table/tbody/tr[2]/td/table/tbody/tr[1]/td[2]")).getText();
				System.out.println("Tender Fee : "+fetchTenderFee);
				
				//Fetch EMD Amount
				String fetchEMDAmount = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[9]/td/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table/tbody/tr[1]/td[2]")).getText();
				System.out.println("Tender EMD Amount : "+fetchEMDAmount);
				
				
				//Fetch Period of working days
				String fetchWorkingdays = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[14]/td/table/tbody/tr[6]/td[6]")).getText();
				System.out.println("Working days : "+fetchWorkingdays);
				
				//Fetch Pre Bid meeting date
				String preBidMeetingDate = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[14]/td/table/tbody/tr[8]/td[4]")).getText();
				System.out.println("Bid Meeting date : "+preBidMeetingDate);
				
				//Fetch Pre Bid meeting address
				String preBidMeetingAdd = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[14]/td/table/tbody/tr[7]/td[6]")).getText();
				System.out.println("Bid Address : "+preBidMeetingAdd);
				
				//Bid submission start date
				String fetchBidSubmissionstartDate = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[17]/td/table/tbody/tr[4]/td[2]")).getText();
				System.out.println("Bid SubmissionDate : "+fetchBidSubmissionstartDate);
				
				//Bid submission end date
				String fetchBidSubmissionendDate = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[17]/td/table/tbody/tr[4]/td[4]")).getText();
				System.out.println("Bid SubmissionDate : "+fetchBidSubmissionendDate);
				
				//Bid opening date 
				String fetchBidOpeningDate = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[17]/td/table/tbody/tr[1]/td[4]")).getText();
				System.out.println("Bid Opening Date : "+fetchBidOpeningDate);
				
				//Click on back button
				MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='DirectLink_10']")).click();
				
				Calendar calendar = Calendar.getInstance();
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
				
				/*FileWriter fr=new FileWriter("C:\\New folder\\"+formatter.format(calendar.getTime())+".txt");
				BufferedWriter br=new BufferedWriter(fr);
				*/
				
				BufferedWriter br = new BufferedWriter(
                        new FileWriter("C:\\New folder\\"+ filename +formatter.format(calendar.getTime())+".txt", true));
				 System.out.println(br);
				 
				/* WritableFont bold10font = new WritableFont(WritableFont.TAHOMA,10,WritableFont.BOLD,false,UnderlineStyle.NO_UNDERLINE, Colour.BLUE); 
				 WritableCellFormat bold10format = new WritableCellFormat (bold10font);
				 bold10format.setWrap(true);
				 WritingDatainFile();*/
				    br.write("Org Chain: "+MahaTendersWebsiteAutomation.elementPath);
					br.newLine();  
					br.write("Org dept: "+Forloop.fetchzonefirst2);
					br.newLine();   
					br.write("Tender ID: " +fetchTenderID);
					br.newLine();
					br.write("Form of contract: "+formOfContract);
					br.newLine();
					br.write("Tender Title: "+fetchTenderTitle);
					br.newLine();
					br.write("Tender Value: "+fetchTenderValue);
					br.newLine();
					br.write("Tender Fee: "+fetchTenderFee);
					br.newLine();
					br.write("EMD Amount: "+fetchEMDAmount);
					br.newLine();
					br.write("Working days: "+fetchWorkingdays);
					br.newLine();
					br.write("Pre Bid meeting date: "+preBidMeetingDate);
					br.newLine();
					br.write("Pre Bid meeting add: "+preBidMeetingAdd);
					br.newLine();
					br.write("Bid Submission startDate: "+fetchBidSubmissionstartDate);
					br.newLine();
					br.write("Bid Submission endDate: "+fetchBidSubmissionendDate);
					br.newLine();
					br.write("Bid Opening Date: "+fetchBidOpeningDate);
					//br.newLine();
					//br.write("Link: "+currentURL);
					br.newLine();
					br.close();
	}
	
 
}
