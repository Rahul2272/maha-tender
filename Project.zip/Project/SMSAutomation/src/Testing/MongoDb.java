package Testing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.bson.Document;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoCredential;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;


public class MongoDb {
	public static WebDriver driver;

	public static void main(String[] args) 
	{
		//System.setProperty("webdriver.chrome.driver", "C:\\Applications\\chromedriver_win32\\chromedriver.exe");
		 
		// Initialize browser
	//	 driver=new ChromeDriver();

		
		MongoClientURI uri = new MongoClientURI("mongodb+srv://RAM:<RAM1233>@cluster0-0b5zd.mongodb.net/test?retryWrites=true&w=majority");
		MongoClient mongoClient = new MongoClient(uri);
		
		//MongoClient mongoClient = new MongoClient("mongodb+srv://RAM:<RAM1233>@cluster0-0b5zd.mongodb.net/test?retryWrites=true&w=majority",27017);
		 
		 MongoCredential credential = MongoCredential.createCredential("RAM", "MahaTender","RAM1233".toCharArray()); 
		 System.out.println("Connected to the database successfully");  
	      
		 MongoDatabase database = mongoClient.getDatabase("MahaTender");
		 System.out.println("Collection created successfully");
		 
	
		 MongoCollection<Document> collection = database.getCollection("MahaTenderCollection"); 
		 System.out.println("Collection myCollection selected successfully"); 
		
		 Document document = new Document("title", "MongoDB") 
			      .append("id", 1)
			      .append("description", "database") 
			      .append("likes", 100) 
			      .append("url", "http://www.tutorialspoint.com/mongodb/") 
			      .append("by", "tutorials point");  
			      collection.insertOne(document); 
			      System.out.println("Document inserted successfully");     
		 
	}

}
