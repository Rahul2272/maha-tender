package Testing;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.By;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

public class JsonFIle
{
	public void FetchRequireddataWithzone(String filename) throws IOException, Exception
	{
	//Organization Chain
	//     fetchOrganizationChain = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[1]/td[2]")).getText();
	//	System.out.println("Org chain :"+fetchOrganizationChain);

		//fetch Tender ID
		String fetchTenderID = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[3]/td[2]")).getText();
		System.out.println("Tender ID :"+fetchTenderID);

		//Fetch Form of contract
		String	formOfContract = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[4]/td[4]")).getText();
		System.out.println("Form of contract : "+formOfContract);
		
		//fetch title 
		String fetchTenderTitle = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[14]/td/table/tbody/tr[1]/td[2]")).getText();
		System.out.println("Tender Title :"+fetchTenderTitle);
		
		//Fetch Tender value
		String fetchTenderValue = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[14]/td/table/tbody/tr[5]/td[2]")).getText();
		System.out.println("Tender Value : "+fetchTenderValue);
		
		//Fetch Tender Fee
		String fetchTenderFee = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[9]/td/table/tbody/tr/td[1]/table/tbody/tr[2]/td/table/tbody/tr[1]/td[2]")).getText();
		System.out.println("Tender Fee : "+fetchTenderFee);
		
		//Fetch EMD Amount
		String fetchEMDAmount = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[9]/td/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table/tbody/tr[1]/td[2]")).getText();
		System.out.println("Tender EMD Amount : "+fetchEMDAmount);
		
		
		//Fetch Period of working days
		String fetchWorkingdays = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[14]/td/table/tbody/tr[6]/td[6]")).getText();
		System.out.println("Working days : "+fetchWorkingdays);
		
		//Fetch Pre Bid meeting date
		String preBidMeetingDate = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[14]/td/table/tbody/tr[8]/td[4]")).getText();
		System.out.println("Bid Meeting date : "+preBidMeetingDate);
		
		//Fetch Pre Bid meeting address
		String preBidMeetingAdd = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[14]/td/table/tbody/tr[7]/td[6]")).getText();
		System.out.println("Bid Address : "+preBidMeetingAdd);
		
		//Bid submission start date
		String fetchBidSubmissionstartDate = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[17]/td/table/tbody/tr[4]/td[2]")).getText();
		System.out.println("Bid SubmissionDate : "+fetchBidSubmissionstartDate);
		
		//Bid submission end date
		String fetchBidSubmissionendDate = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[17]/td/table/tbody/tr[4]/td[4]")).getText();
		System.out.println("Bid SubmissionDate : "+fetchBidSubmissionendDate);
		
		//Bid opening date 
		String fetchBidOpeningDate = MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[2]/tbody/tr/td/table/tbody/tr[17]/td/table/tbody/tr[1]/td[4]")).getText();
		System.out.println("Bid Opening Date : "+fetchBidOpeningDate);
		
		//Click on back button
		MahaTendersWebsiteAutomation.driver.findElement(By.xpath("//*[@id='DirectLink_10']")).click();
		
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		

        	 JSONObject tenderObj = new JSONObject(); 
        	 tenderObj.put("Org Chain: ",MahaTendersWebsiteAutomation.elementPath );
        	 tenderObj.put("Org dept: ", Forloop.fetchzonefirst2);
        	 tenderObj.put("Tender ID: ", fetchTenderID);
        	 tenderObj.put("Form of contract: ", formOfContract);
        	 tenderObj.put("Tender Title: ", fetchTenderTitle);
        	 tenderObj.put("Tender Value: ", fetchTenderValue);
        	 tenderObj.put("Tender Fee: ", fetchTenderFee);
        	 tenderObj.put("EMD Amount: ", fetchEMDAmount);
        	 tenderObj.put("Working days: ", fetchWorkingdays);
        	 tenderObj.put("Pre Bid meeting date: ", fetchWorkingdays);
        	 tenderObj.put("Pre Bid meeting date: ", preBidMeetingDate);
        	 tenderObj.put("Pre Bid meeting add: ", preBidMeetingAdd);
        	 tenderObj.put("Bid Submission startDate: ", fetchBidSubmissionstartDate);
        	 tenderObj.put("Bid Submission endDate: ", fetchBidSubmissionendDate);
        	 tenderObj.put("Bid Opening Date: ", fetchBidOpeningDate);
        	 
        	 
      
    		 //Write JSON file
            try (FileWriter file = new FileWriter("C:\\New folder\\"+ filename +formatter.format(calendar.getTime())+".json"))
            {
            	 file.write(tenderObj.toJSONString());  
                 file.flush();  
                 System.out.println("HI");
                 file.close(); 
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            MongoClient mongoClient = new MongoClient("mongodb+srv://RAM:<RAM1233>@cluster0-0b5zd.mongodb.net/test?retryWrites=true&w=majority");
            MongoDatabase database = mongoClient.getDatabase("MahaTender");
    	}
    	
	}

