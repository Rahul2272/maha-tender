package Testing;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver.When;

public class MahaTendersWebsiteAutomation
{
	private static final String String = null;
	public static WebDriver driver;
	public static String foundele;
	public static String elementPath;

	public static int a ;
	public static int[] elePath ;
	
	
	public static final String b = "Pimpri Chinchwad Municipal Corporation";
	public static final String c = "Pimpri-Chinchwad New Town Development Authority";
	public static final String d = "Pune Metropolitan Regional Development Authority Pune";
	public static final String e = "Pune Municipal Corporation";
	public static final String f = "Public Works Region-Pune";
//	public static String datexp = "14-Oct-2019";
	
	
		
	public static void main(String[] args) throws Exception 
	{
		
		System.setProperty("webdriver.chrome.driver", "C:\\Applications\\chromedriver_win32\\chromedriver.exe");
		 
		// Initialize browser
		 driver=new ChromeDriver();
		 
		 Forloop loop =  new Forloop();
		 
		// Open website
		driver.get("https://mahatenders.gov.in");
		 
		// Maximize browser
		 Thread.sleep(7000);
		driver.manage().window().maximize();
		
		
		//Click on tenders by organizations
 	    driver.findElement(By.xpath("//table/tbody/tr[2]/td/table/tbody/tr/td[1]/table/tbody/tr[2]/td/table/tbody/tr[8]/td")).click();
 		Thread.sleep(700);
		
		WebElement table = driver.findElement(By.xpath("//*[@id='table']/tbody"));
		List<WebElement> row = table.findElements(By.tagName("tr"));
		
		System.out.println("Row : "+row.size());
		
		  //First element from 2nd row
		 elePath = new int[] {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,
					77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,
					143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,
					177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,
					236,237,238,239,240,241,242,243,244,245,246,247,248,249,250};
		
		Thread.sleep(7000);
		
		for ( a=2 ; a < (row.size()-2); a++)
		{
			elementPath = driver.findElement(By.xpath("//*[@id='informal_"+elePath[a]+"']/td[2]")).getText();
			
			
			System.out.println(elementPath);
			
			switch(elementPath)
		     {
		     case b : 
		    	 if(b.equals(elementPath))
		    	 {
		    		 System.out.println(b);
		    		 loop.executeForLoop();
				 }
				break;
		     case c : 
		    	 if(c.equals(elementPath))
		    	 {
		    		 System.out.println(c);
		    		 loop.executeForLoop();
		    	 }
		     	break;
		     case d : 
		    	 if(d.equals(elementPath))
		    	 {
		    		 System.out.println(d);
		    		 loop.executeForLoop();
		    	 }
		     	break;
		     case e : 
		    	 if(e.equals(elementPath))
		    	 {
		    		 System.out.println(e);
		    		 loop.executeForLoop();
		    	 }
		     	break;
		     case f : 
		    	 if(f.equals(elementPath))
		    	 {
		    	 	System.out.println(f);
		    		loop.executeForLoop();
		    	 }
		     	break;
				
				default: 
				{
					System.out.println("Default");
				}
				break;
		     }
		}	
			
		driver.quit();
			}
     }


